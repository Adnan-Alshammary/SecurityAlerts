"""

"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'run_query_1' block
    run_query_1(container=container)

    return

@phantom.playbook_block()
def run_query_1(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("run_query_1() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    parameters = []

    parameters.append({
        "query": "| inputlookup secalerts_settings.csv where setting=\"query\"",
        "search_mode": "smart",
        "add_raw_field": False,
        "attach_result": True,
    })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("run query", parameters=parameters, name="run_query_1", assets=["fetch_escalated_alerts"], callback=format_1)

    return


@phantom.playbook_block()
def format_1(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("format_1() called")

    template = """{0} | eventstats last(created) as last_created_date by alert_id \n| where last_created_date == created\n|fields - secalert_comments_meta last_status last_disposition last_assigned_to"""

    # parameter list for template variable replacement
    parameters = [
        "run_query_1:action_result.data.0.attr1"
    ]

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.format(container=container, template=template, parameters=parameters, name="format_1")

    run_query_2(container=container)

    return


@phantom.playbook_block()
def run_query_2(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("run_query_2() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    playbook_input_latest_time = phantom.collect2(container=container, datapath=["playbook_input:latest_time"])
    playbook_input_earliest_time = phantom.collect2(container=container, datapath=["playbook_input:earliest_time"])
    format_1 = phantom.get_format_data(name="format_1")

    parameters = []

    # build parameters list for 'run_query_2' call
    for playbook_input_latest_time_item in playbook_input_latest_time:
        for playbook_input_earliest_time_item in playbook_input_earliest_time:
            if format_1 is not None:
                parameters.append({
                    "query": format_1,
                    "command": "",
                    "end_time": playbook_input_latest_time_item[0],
                    "parse_only": False,
                    "start_time": playbook_input_earliest_time_item[0],
                    "search_mode": "smart",
                    "add_raw_field": False,
                    "attach_result": True,
                })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("run query", parameters=parameters, name="run_query_2", assets=["fetch_escalated_alerts"])

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    run_query_2_result_data = phantom.collect2(container=container, datapath=["run_query_2:action_result.data"])

    run_query_2_result_item_0 = [item[0] for item in run_query_2_result_data]

    output = {
        "alerts_list": run_query_2_result_item_0,
    }

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_playbook_output_data(output=output)

    return