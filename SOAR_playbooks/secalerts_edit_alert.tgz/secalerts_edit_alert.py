"""

"""


import phantom.rules as phantom
import json
from datetime import datetime, timedelta


@phantom.playbook_block()
def on_start(container):
    phantom.debug('on_start() called')

    # call 'decision_1' block
    decision_1(container=container)

    return

@phantom.playbook_block()
def run_query_1(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("run_query_1() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    format_1 = phantom.get_format_data(name="format_1")

    parameters = []

    if format_1 is not None:
        parameters.append({
            "query": format_1,
            "search_mode": "smart",
            "add_raw_field": False,
            "attach_result": True,
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("run query", parameters=parameters, name="run_query_1", assets=["fetch_escalated_alerts"], callback=code_3)

    return


@phantom.playbook_block()
def format_1(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("format_1() called")

    template = """| inputlookup secalerts_comments where alert_id=\"{0}\"\n| eventstats max(created) as themax by alert_id\n| where themax == created\n| fields - themax"""

    # parameter list for template variable replacement
    parameters = [
        "playbook_input:alert_id"
    ]

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.format(container=container, template=template, parameters=parameters, name="format_1")

    run_query_1(container=container)

    return


@phantom.playbook_block()
def join_format_2(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("join_format_2() called")

    required_code_blocks_completed = all([phantom.get_block_result(key=f"{code_block}_called") == "True" for code_block in ["code_3"]])

    if phantom.completed(code_names=["code_3"], action_names=["run_query_3"]) and required_code_blocks_completed:
        # call connected block "format_2"
        format_2(container=container, handle=handle)

    return


@phantom.playbook_block()
def format_2(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("format_2() called")

    template = """|makeresults | eval alert_id=\"{0}\" | eval customkey=\"{5}\"+\"__\"+\"{0}\"+\"__\"+tostring(_time)+\"__\"+tostring(random())\n|rename _time as created|eval user=\"{5}\"|eval comment=\"{1}\"| eval status=\"{2}\" | eval disposition=\"{3}\" | eval assigned_to=\"{4}\" |outputlookup append=true secalerts_comments"""

    # parameter list for template variable replacement
    parameters = [
        "playbook_input:alert_id",
        "playbook_input:comment",
        "code_3:custom_function:final_status",
        "code_3:custom_function:final_disosition",
        "code_3:custom_function:final_assigned_to",
        "run_query_3:action_result.data.0.username"
    ]

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.format(container=container, template=template, parameters=parameters, name="format_2")

    run_query_2(container=container)

    return


@phantom.playbook_block()
def run_query_2(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("run_query_2() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    format_2 = phantom.get_format_data(name="format_2")

    parameters = []

    if format_2 is not None:
        parameters.append({
            "query": format_2,
            "search_mode": "smart",
            "add_raw_field": True,
        })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("run query", parameters=parameters, name="run_query_2", assets=["fetch_escalated_alerts"], callback=join_code_5)

    return


@phantom.playbook_block()
def code_3(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("code_3() called")

    playbook_input_disposition = phantom.collect2(container=container, datapath=["playbook_input:disposition"])
    playbook_input_status = phantom.collect2(container=container, datapath=["playbook_input:status"])
    playbook_input_assigned_to = phantom.collect2(container=container, datapath=["playbook_input:assigned_to"])

    playbook_input_disposition_values = [item[0] for item in playbook_input_disposition]
    playbook_input_status_values = [item[0] for item in playbook_input_status]
    playbook_input_assigned_to_values = [item[0] for item in playbook_input_assigned_to]

    code_3__final_disosition = None
    code_3__final_status = None
    code_3__final_assigned_to = None

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...
    if not playbook_input_disposition_values:
        query_disposition = phantom.collect2(container=container, datapath=["run_query_1:action_result.data.*.disposition"], action_results=results)
        playbook_input_disposition_values = [item[0] for item in query_disposition if item and item[0]]
        if not playbook_input_disposition_values:
             code_3__final_disosition=["Undetermined"]
        else:
            code_3__final_disosition=playbook_input_disposition_values
    else:
             code_3__final_disosition=playbook_input_disposition_values
            
    if not playbook_input_status_values:
        query_status = phantom.collect2(container=container, datapath=["run_query_1:action_result.data.*.status"], action_results=results)
        playbook_input_status_values = [item[0] for item in query_status if item and item[0]]
        if not playbook_input_status_values:
            code_3__final_status=["New"]
        else:
            code_3__final_status=playbook_input_status_values            
    else:
            code_3__final_status=playbook_input_status_values
            
    if not playbook_input_assigned_to_values:
        query_assigned_to = phantom.collect2(container=container, datapath=["run_query_1:action_result.data.*.assigned_to"], action_results=results)
        playbook_input_assigned_to_values = [item[0] for item in query_assigned_to if item and item[0]]
        if not playbook_input_assigned_to_values:
            code_3__final_assigned_to=["Unassigned"]
        else:
            code_3__final_assigned_to=playbook_input_assigned_to_values            
    else:
            code_3__final_assigned_to=playbook_input_assigned_to_values
        
    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="code_3__inputs:0:playbook_input:disposition", value=json.dumps(playbook_input_disposition_values))
    phantom.save_block_result(key="code_3__inputs:1:playbook_input:status", value=json.dumps(playbook_input_status_values))
    phantom.save_block_result(key="code_3__inputs:2:playbook_input:assigned_to", value=json.dumps(playbook_input_assigned_to_values))

    phantom.save_block_result(key="code_3:final_disosition", value=json.dumps(code_3__final_disosition))
    phantom.save_block_result(key="code_3:final_status", value=json.dumps(code_3__final_status))
    phantom.save_block_result(key="code_3:final_assigned_to", value=json.dumps(code_3__final_assigned_to))

    phantom.save_block_result(key="code_3_called", value="True")

    join_format_2(container=container)

    return


@phantom.playbook_block()
def run_query_3(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("run_query_3() called")

    # phantom.debug('Action: {0} {1}'.format(action['name'], ('SUCCEEDED' if success else 'FAILED')))

    parameters = []

    parameters.append({
        "query": "| rest /services/authentication/current-context | fields username",
        "search_mode": "smart",
        "add_raw_field": True,
        "attach_result": True,
    })

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.act("run query", parameters=parameters, name="run_query_3", assets=["fetch_escalated_alerts"], callback=join_format_2)

    return


@phantom.playbook_block()
def decision_1(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("decision_1() called")

    # check for 'if' condition 1
    found_match_1 = phantom.decision(
        container=container,
        conditions=[
            ["playbook_input:alert_id", "matches regex", "^[a-fA-F0-9]{32}$"]
        ],
        conditions_dps=[
            ["playbook_input:alert_id", "matches regex", "^[a-fA-F0-9]{32}$"]
        ],
        name="decision_1:condition_1",
        delimiter=None)

    # call connected blocks if condition 1 matched
    if found_match_1:
        format_1(action=action, success=success, container=container, results=results, handle=handle)
        run_query_3(action=action, success=success, container=container, results=results, handle=handle)
        return

    # check for 'else' condition 2
    join_code_5(action=action, success=success, container=container, results=results, handle=handle)

    return


@phantom.playbook_block()
def join_code_5(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("join_code_5() called")

    # if the joined function has already been called, do nothing
    if phantom.get_run_data(key="join_code_5_called"):
        return

    # save the state that the joined function has now been called
    phantom.save_block_result(key="join_code_5_called", value="code_5")

    # call connected block "code_5"
    code_5(container=container, handle=handle)

    return


@phantom.playbook_block()
def code_5(action=None, success=None, container=None, results=None, handle=None, filtered_artifacts=None, filtered_results=None, custom_function=None, loop_state_json=None, **kwargs):
    phantom.debug("code_5() called")

    playbook_input_alert_id = phantom.collect2(container=container, datapath=["playbook_input:alert_id"])

    playbook_input_alert_id_values = [item[0] for item in playbook_input_alert_id]

    code_5__alert_id_validation = None

    ################################################################################
    ## Custom Code Start
    ################################################################################
    import re

    if re.match("^[a-fA-F0-9]{32}$",playbook_input_alert_id_values[0]):

        code_5__alert_id_validation="valid alert ID"

    else:

        code_5__alert_id_validation="Error: invalid alert ID"
    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_block_result(key="code_5__inputs:0:playbook_input:alert_id", value=json.dumps(playbook_input_alert_id_values))

    phantom.save_block_result(key="code_5:alert_id_validation", value=json.dumps(code_5__alert_id_validation))

    phantom.save_block_result(key="code_5_called", value="True")

    return


@phantom.playbook_block()
def on_finish(container, summary):
    phantom.debug("on_finish() called")

    code_5__alert_id_validation = json.loads(_ if (_ := phantom.get_run_data(key="code_5:alert_id_validation")) != "" else "null")  # pylint: disable=used-before-assignment

    output = {
        "check_alert_id": code_5__alert_id_validation,
    }

    ################################################################################
    ## Custom Code Start
    ################################################################################

    # Write your custom code here...

    ################################################################################
    ## Custom Code End
    ################################################################################

    phantom.save_playbook_output_data(output=output)

    return